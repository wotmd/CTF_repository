﻿KEY FORMAT

A is on : A
A is off : A'

Gate’s result : BEAR 
Find switch’s state when BEAR

KEY : BEAR’s switch on or off+ BEAR BASE64 ENCODING